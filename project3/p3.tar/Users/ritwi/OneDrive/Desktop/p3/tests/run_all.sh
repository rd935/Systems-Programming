make clean
make mysh
make arraylist_tester
make token_tester
make print_args
make reader
./arraylist_tester
./token_tester
./mysh tests/helloworld.sh
./mysh tests/cd_test
./mysh tests/myscript.sh
./mysh