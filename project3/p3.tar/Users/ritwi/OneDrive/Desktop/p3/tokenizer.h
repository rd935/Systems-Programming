#ifndef TOKENIZER_H
#define TOKENIZER_H

int tokenizer(arrlist*, char*);

#endif